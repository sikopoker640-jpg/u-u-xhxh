package com.example.gamecleaner

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * AI agent: every step it takes a screenshot, sends it to Claude, Claude READS the screen
 * (any language, incl. Arabic) and answers with one action (tap / back / wait / done),
 * and the app performs it. Needs an API key (saved in the app) and Android 11+.
 */
class AiAgent(private val svc: ClearService) {
    private val h = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()
    private var running = false
    private var steps = 0
    private var bubble: TextView? = null
    private val history = ArrayDeque<String>()
    private var lastTap = ""
    private var sameTap = 0

    companion object {
        const val MAX_STEPS = 80
        const val DEFAULT_MODEL = "claude-sonnet-5-5"
        const val SYSTEM = """You control an Android phone playing the card game "Texas Poker" (Boyaa, Arabic UI), shown in landscape screenshots.
GOAL: collect every free in-game reward you can see from the Missions (المهام / MISSION) panels: open Mission from the lobby, then in every tab (مهام المبتدئين, مهمة يومية, مهمة انجازات) tap each active gold claim button (تلقي / استلام / Collect / Claim). Buttons that are grey, say "تم", or are already claimed must be ignored. If a mission needs playing a hand, go to a table (quick start / بدأ سريع) and play: when it is your turn tap the green Check/Call button, never raise or go all-in. When no rewards are left, close dialogs and answer done.
Close any promo/ad/pop-up with its X or a Close/Later button.
HARD RULES: NEVER tap anything about shop, store, recharge, top-up, buy, purchase, deposit, payment, VIP purchase, subscriptions, ads you must watch, invite/share, or any real-money item. Never type text. If unsure, answer wait.
Answer with ONE JSON object only, no other text:
{"action":"tap","x":0-1000,"y":0-1000,"why":"short reason"}  (x,y = position inside the image, 0,0 top-left, 1000,1000 bottom-right)
or {"action":"back"} or {"action":"wait"} or {"action":"done"}."""
    }

    fun showBubble() {
        if (bubble != null) return
        val wm = svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager
        val d = svc.resources.displayMetrics.density
        val size = (52 * d).toInt()
        val tv = TextView(svc).apply {
            text = "AI"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val lp = WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = (200 * d).toInt() }
        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (running) stop() else start() }
            }
            true
        }
        wm.addView(tv, lp); bubble = tv; paint()
    }

    fun hideBubble() {
        stop()
        bubble?.let { (svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager).removeView(it) }
        bubble = null
    }

    private fun paint() {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (running) 0xFF1B8E3E.toInt() else 0xFF6D28D9.toInt())
            setStroke(4, 0x66FFFFFF)
        }
    }

    private fun toast(t: String) = h.post { Toast.makeText(svc, t, Toast.LENGTH_LONG).show() }

    private fun start() {
        val key = svc.getSharedPreferences("p", AccessibilityService.MODE_PRIVATE).getString("akey", "")?.trim().orEmpty()
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ required"); return }
        if (key.isEmpty()) { toast("API key: ل ئەپی بنڤیسە (Game Cleaner)"); return }
        running = true; steps = 0; history.clear(); lastTap = ""; sameTap = 0; paint()
        h.postDelayed({ step() }, 500)
    }

    fun stop() { running = false; h.removeCallbacksAndMessages(null); paint() }

    private fun step() {
        if (!running || Build.VERSION.SDK_INT < 30) return
        if (steps++ >= MAX_STEPS) { toast("AI: max steps"); stop(); return }
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false); hb.close()
                    if (bmp == null) { h.post { stop() }; return }
                    val b64 = encode(bmp)
                    val reply = ask(b64)
                    h.post { act(reply, bmp.width, bmp.height) }
                } catch (e: Exception) {
                    toast("AI error: " + (e.message ?: e.javaClass.simpleName)); h.post { stop() }
                }
            }
            override fun onFailure(code: Int) { toast("Screenshot failed ($code)"); h.post { stop() } }
        })
    }

    private fun encode(src: Bitmap): String {
        val w = 1280; val hh = (src.height * w / src.width.toFloat()).toInt()
        val s = Bitmap.createScaledBitmap(src, w, hh, true)
        val o = ByteArrayOutputStream(); s.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun ask(b64: String): String {
        val p = svc.getSharedPreferences("p", AccessibilityService.MODE_PRIVATE)
        val key = p.getString("akey", "")?.trim().orEmpty()
        val model = p.getString("amodel", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
        val hist = if (history.isEmpty()) "none" else history.joinToString(" | ")
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text", "Your last actions: $hist\nWhat is the next single action?"))
        val body = JSONObject().put("model", model).put("max_tokens", 300).put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("HTTP $code " + txt.take(120))
        return JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }

    private fun act(reply: String, w: Int, hh: Int) {
        if (!running) return
        val a = try {
            JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
        } catch (e: Exception) { history.addLast("unparsable"); h.postDelayed({ step() }, 1500); return }
        when (a.optString("action")) {
            "tap" -> {
                val x = a.optDouble("x", -1.0); val y = a.optDouble("y", -1.0)
                if (x !in 0.0..1000.0 || y !in 0.0..1000.0) { h.postDelayed({ step() }, 1200); return }
                val key = "${(x / 40).toInt()},${(y / 40).toInt()}"
                sameTap = if (key == lastTap) sameTap + 1 else 0; lastTap = key
                if (sameTap >= 3) { toast("AI: stuck, stopped"); stop(); return }
                svc.tapPx((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat())
                history.addLast("tap(${x.toInt()},${y.toInt()}) " + a.optString("why").take(40))
                if (history.size > 6) history.removeFirst()
                h.postDelayed({ step() }, 2200)
            }
            "back" -> { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); history.addLast("back"); h.postDelayed({ step() }, 1800) }
            "wait" -> { history.addLast("wait"); h.postDelayed({ step() }, 2500) }
            "done" -> { toast("AI: done ✔"); stop() }
            else -> h.postDelayed({ step() }, 1500)
        }
        if (history.size > 6) history.removeFirst()
    }
}
