package com.example.gamecleaner

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.accessibilityservice.AccessibilityService
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

/**
 * Claims in-game mission rewards by LOOKING at the screen (the game is drawn on a canvas,
 * so there are no readable text nodes). Open the Mission panel yourself, then tap the gold
 * "Claim" bubble: it finds every gold "تلقي" button and taps it, then stops by itself.
 */
class MissionClaimer(private val svc: ClearService) {
    private val h = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()
    private var running = false
    private var empty = 0
    private var bubble: TextView? = null

    fun showBubble() {
        if (bubble != null) return
        val wm = svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager
        val d = svc.resources.displayMetrics.density
        val size = (52 * d).toInt()
        val tv = TextView(svc).apply {
            text = "Claim"; textSize = 11f; gravity = Gravity.CENTER
            setTextColor(Color.BLACK); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val lp = WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 120 }
        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) toggle()
            }
            true
        }
        wm.addView(tv, lp); bubble = tv; paint()
    }

    fun hideBubble() {
        stop()
        bubble?.let { (svc.getSystemService(AccessibilityService.WINDOW_SERVICE) as WindowManager).removeView(it) }
        bubble = null
    }

    private fun paint() {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (running) 0xFF1B8E3E.toInt() else 0xFFF2B33D.toInt())
        }
    }

    private fun toggle() { if (running) stop() else start() }

    private fun start() {
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(svc, "Android 11+ required", Toast.LENGTH_LONG).show(); return
        }
        running = true; empty = 0; paint(); h.postDelayed({ round() }, 400)
    }

    fun stop() { running = false; h.removeCallbacksAndMessages(null); paint() }

    private fun round() {
        if (!running || Build.VERSION.SDK_INT < 30) return
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                val hit = bmp?.let { find(it) }
                val w = bmp?.width ?: 1; val hh = bmp?.height ?: 1
                h.post {
                    if (!running) return@post
                    if (hit != null) {
                        empty = 0
                        svc.tapPx(hit.first * w, hit.second * hh)
                        h.postDelayed({ round() }, 1800)       // wait for the reward animation
                    } else {
                        empty++
                        if (empty >= 3) { stop(); Toast.makeText(svc, "Claim: done", Toast.LENGTH_SHORT).show() }
                        else h.postDelayed({ round() }, 900)
                    }
                }
            }
            override fun onFailure(code: Int) { h.post { stop() } }
        })
    }

    /** Returns the centre (as 0..1 fractions) of the best gold button-shaped blob, or null. */
    private fun find(src: Bitmap): Pair<Float, Float>? {
        val W = 300; val H = (src.height * W / src.width.toFloat()).toInt()
        val b = Bitmap.createScaledBitmap(src, W, H, true)
        val px = IntArray(W * H); b.getPixels(px, 0, W, 0, 0, W, H)
        // only the middle of the screen: keeps the lobby "Quick start" button out of reach
        val x0 = (W * 0.18).toInt(); val x1 = (W * 0.86).toInt()
        val y0 = (H * 0.28).toInt(); val y1 = (H * 0.92).toInt()
        // the Mission panel is purple: if it is not on screen, do nothing
        var purple = 0; var total = 0
        val gold = BooleanArray(W * H)
        for (y in y0 until y1) for (x in x0 until x1) {
            val c = px[y * W + x]; val r = Color.red(c); val g = Color.green(c); val bl = Color.blue(c)
            total++
            if (bl > r + 25 && bl > g + 35 && r in 40..150) purple++
            if (r > 200 && g in 120..205 && bl < 120 && r - bl > 110) gold[y * W + x] = true
        }
        if (purple < total * 0.20) return null
        val seen = BooleanArray(W * H)
        var best: Pair<Float, Float>? = null; var bestArea = 0
        val stack = IntArray(W * H)
        for (y in y0 until y1) for (x in x0 until x1) {
            val i = y * W + x
            if (!gold[i] || seen[i]) continue
            var sp = 0; stack[sp++] = i; seen[i] = true
            var minX = x; var maxX = x; var minY = y; var maxY = y; var area = 0
            while (sp > 0) {
                val j = stack[--sp]; val cx = j % W; val cy = j / W; area++
                if (cx < minX) minX = cx; if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy; if (cy > maxY) maxY = cy
                for (n in intArrayOf(j - 1, j + 1, j - W, j + W)) {
                    if (n < 0 || n >= W * H || seen[n] || !gold[n]) continue
                    val nx = n % W
                    if (Math.abs(nx - cx) > 1 || nx < x0 || nx >= x1 || n / W < y0 || n / W >= y1) continue
                    seen[n] = true; stack[sp++] = n
                }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val fill = area / (bw * bh).toFloat()
            val ratio = bw / bh.toFloat()
            // a button is wide, fairly solid, and much bigger than a falling coin
            if (bw >= 22 && bh >= 8 && ratio in 1.8f..5.5f && fill >= 0.5f && area > bestArea) {
                bestArea = area
                best = Pair((minX + maxX) / 2f / W, (minY + maxY) / 2f / H)
            }
        }
        return best
    }
}
