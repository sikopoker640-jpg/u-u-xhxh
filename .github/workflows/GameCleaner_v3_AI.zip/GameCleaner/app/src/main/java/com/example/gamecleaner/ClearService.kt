package com.example.gamecleaner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class ClearService : AccessibilityService() {
    companion object {
        var inst: ClearService? = null
        const val PG = "com.google.android.play.games"
        val STORAGE = listOf("Storage", "التخزين", "ذخیرەسازی", "Depolama")
        val CLEAR = listOf("Clear data", "Clear storage", "محو البيانات", "مسح البيانات", "محو مساحة التخزين", "داتا بسڕە", "Verileri temizle")
        val SETTINGS = listOf("Settings", "الإعدادات", "ڕێکخستن", "Ayarlar")
        const val DEF_URL = "https://play.google.com/games/profile"
        const val DEF_GAME = "texaspoker-ar"
        val YOURDATA = listOf("Your data")
        val DELMENU = listOf("Delete Play Games account and data", "Delete Play Games account & data")
        val DELBTN = listOf("Delete")
        val PERMDEL = listOf("Permanently delete")
        val PERM = listOf("Allow", "While using the app", "السماح", "أثناء استخدام التطبيق", "ڕێپێدان")
        val CONT = listOf("Continue as", "Continue", "Allow", "Accept", "متابعة", "السماح", "موافق", "بەردەوام بە")
        val GOOGLE = listOf("Sign in with Google", "Google", "Gmail", "تسجيل الدخول باستخدام Google", "تسجيل الدخول بحساب Google", "گووگڵ")
        val CONFIRM = listOf("OK", "Delete", "حسنًا", "حسنا", "موافق", "حذف", "باشە", "Tamam", "Sil")
    }

    var active = false
    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var state = 0
    private var last = 0L
    private var all = listOf<String>()
    private var loop = false
    private var cycleStart = 0L
    private var email = ""
    private var tapX = 0f
    private var tapY = 0f
    private var boxX = 0f
    private var boxY = 0f
    private var clickedGoogle = false
    private var delAcct = false
    private var clearApp = false
    private var webUrl = DEF_URL
    private var gameName = DEF_GAME
    private var box: View? = null
    private var logo: FrameLayout? = null
    private var menu: LinearLayout? = null
    private var chipMaster: TextView? = null
    private var chipPoker: TextView? = null
    private var chipGames: TextView? = null
    private var pokerOn = true

    private var missions: MissionClaimer? = null
    private var ai: AiAgent? = null
    fun tapPx(x: Float, y: Float) = tapAt(maxOf(x, 2f), maxOf(y, 2f))
    override fun onServiceConnected() { inst = this; showOverlay(); missions = MissionClaimer(this).also { it.showBubble() }; ai = AiAgent(this).also { it.showBubble() } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        stop(); missions?.hideBubble(); missions = null; ai?.hideBubble(); ai = null; removeOverlay(); inst = null
        return super.onUnbind(i)
    }

    // ---------- floating logo -> tap -> menu (photo + ON/OFF for Start, Poker, Game Play) ----------
    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    private fun round(v: View, r: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) { o.setRoundRect(0, 0, view.width, view.height, r.toFloat()) }
        }
        v.clipToOutline = true
    }

    private fun photo(w: Int, h: Int, radius: Int, res: Int) = ImageView(this).apply {
        setImageBitmap(BitmapFactory.decodeResource(resources, res))
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = FrameLayout.LayoutParams(w, h)
        round(this, radius)
    }

    private val sat = arrayOfNulls<LinearLayout>(3)   // 0 = Start, 1 = Poker, 2 = Game Play
    private val satText = arrayOfNulls<TextView>(3)
    private var disc: View? = null
    private var isOpen = false
    private var satNames = arrayOf("Start", "Poker", "Game Play")

    private fun showOverlay() {
        if (box != null) return
        val p = getSharedPreferences("p", MODE_PRIVATE)
        pokerOn = p.getBoolean("pk", true); delAcct = p.getBoolean("cb", false)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val L = dp(56); val D = dp(310); val S = dp(76); val RAD = dp(114)
        val off = (D - L) / 2
        val root = FrameLayout(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 320 }

        // big round disc
        val dsc = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xEB0F172A.toInt()); setStroke(dp(2), 0x55FFFFFF) }
            visibility = View.GONE
        }
        root.addView(dsc, FrameLayout.LayoutParams(D, D, Gravity.CENTER))
        disc = dsc

        // three round buttons on a circle, each with its own logo
        val names = arrayOf("Start", "Poker", "Game Play")
        val icons = intArrayOf(R.drawable.ic_start, R.drawable.ic_poker, R.drawable.ic_game)
        val taps = arrayOf<() -> Unit>(
            { if (active) stop() else begin(true) },
            { pokerOn = !pokerOn; getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("pk", pokerOn).apply(); paint() },
            { delAcct = !delAcct; getSharedPreferences("p", MODE_PRIVATE).edit().putBoolean("cb", delAcct).apply(); paint() }
        )
        val angles = doubleArrayOf(-90.0, 30.0, 150.0)
        for (i in 0..2) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setOnClickListener { taps[i]() }; visibility = View.GONE
            }
            col.addView(ImageView(this).apply { setImageResource(icons[i]) }, LinearLayout.LayoutParams(dp(26), dp(26)))
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 11f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            col.addView(tv, LinearLayout.LayoutParams(-2, -2))
            sat[i] = col; satText[i] = tv
            val rad = Math.toRadians(angles[i])
            val cx = D / 2 + (RAD * Math.cos(rad)).toInt(); val cy = D / 2 + (RAD * Math.sin(rad)).toInt()
            root.addView(col, FrameLayout.LayoutParams(S, S).apply { leftMargin = cx - S / 2; topMargin = cy - S / 2 })
        }

        // closed: round face logo.  open: the WHOLE photo in a rounded frame
        val lg = FrameLayout(this).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) }
        lg.addView(photo(L - dp(6), L - dp(6), (L - dp(6)) / 2, R.drawable.profile))
        val CW = dp(104); val CH = dp(156)             // photo is 2:3 (1717x2576)
        val frame = FrameLayout(this).apply {
            setPadding(dp(3), dp(3), dp(3), dp(3)); visibility = View.GONE
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFFFFFFFF.toInt()) }
        }
        frame.addView(photo(CW - dp(6), CH - dp(6), dp(17), R.drawable.photo_full))

        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false
        val touch = View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    isOpen = !isOpen
                    val v = if (isOpen) View.VISIBLE else View.GONE
                    dsc.visibility = v; sat.forEach { it?.visibility = v }
                    frame.visibility = v; lg.visibility = if (isOpen) View.GONE else View.VISIBLE
                    lp.x += if (isOpen) -off else off; lp.y += if (isOpen) -off else off   // keep it where it was
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        lg.setOnTouchListener(touch); frame.setOnTouchListener(touch)
        root.addView(lg, FrameLayout.LayoutParams(L, L, Gravity.CENTER))
        root.addView(frame, FrameLayout.LayoutParams(CW, CH, Gravity.CENTER))
        logo = lg; isOpen = false
        wm.addView(root, lp); box = root; satNames = names; paint()
    }

    private fun removeOverlay() {
        box?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        box = null; logo = null; disc = null; isOpen = false
        for (i in 0..2) { sat[i] = null; satText[i] = null }
    }

    private fun paintSat(i: Int, on: Boolean) {
        satText[i]?.text = satNames[i] + "\n" + (if (on) "ON" else "OFF")
        sat[i]?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(if (on) 0xFF1B8E3E.toInt() else 0xFFC62828.toInt())
            setStroke(dp(2), 0x66FFFFFF)
        }
    }

    private fun paint() {
        paintSat(0, active); paintSat(1, pokerOn); paintSat(2, delAcct)
        logo?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL; setColor(if (active) 0xFF1B8E3E.toInt() else 0xFFC62828.toInt())
        }
    }

    // ---------- control ----------
    fun begin(repeat: Boolean) {
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val xy = (p.getString("xy", "") ?: "").ifBlank { "0.20,0.81" }.split(",").mapNotNull { it.trim().toFloatOrNull() }
        val ck = (p.getString("ck", "") ?: "").ifBlank { "0.32,0.71" }.split(",").mapNotNull { it.trim().toFloatOrNull() }
        h.removeCallbacksAndMessages(null)
        all = (p.getString("list", "") ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }
        loop = repeat
        email = (p.getString("mail", "") ?: "").trim()
        tapX = xy.getOrElse(0) { 0f }; tapY = xy.getOrElse(1) { 0f }
        boxX = ck.getOrElse(0) { 0f }; boxY = ck.getOrElse(1) { 0f }
        delAcct = p.getBoolean("cb", false)
        pokerOn = p.getBoolean("pk", true)
        clearApp = p.getBoolean("clr", false)
        webUrl = (p.getString("url", DEF_URL) ?: DEF_URL).trim().ifEmpty { DEF_URL }
        gameName = (p.getString("gname", DEF_GAME) ?: DEF_GAME).trim().ifEmpty { DEF_GAME }
        active = true; paint()
        performGlobalAction(GLOBAL_ACTION_HOME)
        h.postDelayed({ cycle() }, 1000)
    }

    fun stop() {
        loop = false; state = 0; active = false
        h.removeCallbacksAndMessages(null); paint()
    }

    private fun cycle() {
        cycleStart = System.currentTimeMillis()
        queue.clear(); if (clearApp) queue.addAll(all)
        if (delAcct) beginAcct() else next()
    }

    // ---------- Play Games web: delete ONLY the chosen game's data ----------
    private fun beginAcct() {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = 10; last = System.currentTimeMillis()
        h.postDelayed({ acct() }, 4000)
    }

    private fun acct() {
        if (state < 10) return
        if (!delAcct) { state = 0; next(); return }
        val now = System.currentTimeMillis()
        if (now - last > 25000) { state = 0; next(); return }   // stuck -> skip
        val r = rootInActiveWindow
        if (r != null) when (state) {
            10 -> if (clickExact(r, YOURDATA)) { state = 11; last = now }
            11 -> if (clickContains(r, DELMENU)) { state = 12; last = now }
            12 -> if (clickGameDelete(r)) { state = 13; last = now }
            13 -> if (confirmDialog(r)) {
                state = 14
                h.postDelayed({
                    performGlobalAction(GLOBAL_ACTION_HOME)     // exit like the video
                    state = 0; h.postDelayed({ next() }, 1200)
                }, 2000)
                return
            }
        }
        h.postDelayed({ acct() }, 800)
    }

    private fun text(n: AccessibilityNodeInfo) = (n.text ?: n.contentDescription)?.toString()?.trim() ?: ""

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out)
    }

    private fun clickUp(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        return c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun clickExact(root: AccessibilityNodeInfo, words: List<String>): Boolean {
        val all = mutableListOf<AccessibilityNodeInfo>(); walk(root, all)
        val n = all.firstOrNull { x -> words.any { text(x).equals(it, true) } } ?: return false
        return clickUp(n)
    }

    private fun clickContains(root: AccessibilityNodeInfo, words: List<String>): Boolean {
        val all = mutableListOf<AccessibilityNodeInfo>(); walk(root, all)
        val n = all.firstOrNull { x -> words.any { text(x).contains(it, true) } } ?: return false
        return clickUp(n)
    }

    // Click the "Delete" button that sits in the SAME row as the game name (never the account section)
    private fun clickGameDelete(root: AccessibilityNodeInfo): Boolean {
        val all = mutableListOf<AccessibilityNodeInfo>(); walk(root, all)
        val g = all.firstOrNull { text(it).contains(gameName, true) } ?: return false
        var row: AccessibilityNodeInfo? = g.parent
        var up = 0
        while (row != null && up < 6) {
            val sub = mutableListOf<AccessibilityNodeInfo>(); walk(row, sub)
            val btn = sub.firstOrNull { text(it).equals("Delete", true) }
            if (btn != null) return clickUp(btn)
            row = row.parent; up++
        }
        return false
    }

    // Confirm ONLY the dialog titled "Delete data for <game>?"
    private fun confirmDialog(root: AccessibilityNodeInfo): Boolean {
        val all = mutableListOf<AccessibilityNodeInfo>(); walk(root, all)
        val title = all.firstOrNull {
            val t = text(it); t.contains("Delete data for", true) && t.contains(gameName, true)
        } ?: return false
        val tb = android.graphics.Rect(); title.getBoundsInScreen(tb)
        var box: AccessibilityNodeInfo? = title.parent
        var up = 0
        while (box != null && up < 5) {
            val sub = mutableListOf<AccessibilityNodeInfo>(); walk(box, sub)
            val btns = sub.filter { text(it).equals("Permanently delete", true) }
            if (btns.isNotEmpty()) {
                val r = android.graphics.Rect()
                val pick = btns.filter { it.getBoundsInScreen(r); r.top >= tb.bottom }
                    .minByOrNull { it.getBoundsInScreen(r); r.top - tb.bottom } ?: return false
                return clickUp(pick)
            }
            box = box.parent; up++
        }
        return false
    }

    private fun next() {
        if (queue.isEmpty()) {
            state = 0
            if (!loop) { active = false; paint(); performGlobalAction(GLOBAL_ACTION_HOME); return }
            if (pokerOn) {
                val game = all.firstOrNull()
                val li = game?.let { packageManager.getLaunchIntentForPackage(it) }
                if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                clickedGoogle = false
                h.postDelayed({ login(0) }, 8000)
            }
            val wait = maxOf(3000L, 60000L - (System.currentTimeMillis() - cycleStart))
            h.postDelayed({ if (loop) cycle() }, wait)
            return
        }
        val p = queue.removeFirst()
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = 1; last = System.currentTimeMillis()
        h.postDelayed({ tick() }, 1500)
    }

    private fun tick() {
        if (state == 0) return
        if (System.currentTimeMillis() - last > 12000) { next(); return }
        val r = rootInActiveWindow
        if (r != null) {
            when (state) {
                1, 2 -> {
                    if (click(r, CLEAR)) { state = 3; last = System.currentTimeMillis() }
                    else if (state == 1 && click(r, STORAGE)) { state = 2; last = System.currentTimeMillis() }
                }
                3 -> if (click(r, CONFIRM)) { state = 4; h.postDelayed({ next() }, 1200); return }
            }
        }
        h.postDelayed({ tick() }, 800)
    }

    // ---------- poker login, like the video ----------
    // 1) tick "I agree" box  2) tap "Sign in with Google" (game canvas -> by position)
    // 3) Google consent: scroll down (the arrow), then Continue
    private var tappedBox = false
    private var consentTicks = 0

    private fun tapAt(x: Float, y: Float) {
        if (x <= 0f && y <= 0f) return
        val dm = android.util.DisplayMetrics()
        val wmg = getSystemService(WINDOW_SERVICE) as WindowManager
        wmg.defaultDisplay.getRealMetrics(dm)
        val px = if (x <= 1f) x * dm.widthPixels else x      // 0..1 = fraction of the (landscape) screen
        val py = if (y <= 1f) y * dm.heightPixels else y
        val path = Path().apply { moveTo(px, py) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
    }

    private fun login(n: Int) {
        if (!loop || !pokerOn || n > 50) return
        if (n == 0) { tappedBox = false; consentTicks = 0 }
        val r = rootInActiveWindow
        var acted = false
        if (r != null) {
            val all = mutableListOf<AccessibilityNodeInfo>(); walk(r, all)
            val consent = all.any { text(it).contains("wants access to your Google Account", true) } ||
                (all.any { text(it).equals("Cancel", true) } && all.any { text(it).equals("Continue", true) })
            if (consent) {
                acted = true
                if (consentTicks % 2 == 0) {                       // scroll to the bottom (arrow button)
                    val more = all.firstOrNull { text(it).equals("More", true) }
                    if (more == null || !clickUp(more))
                        all.firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                } else {                                           // then Continue
                    val cont = all.firstOrNull { text(it).equals("Continue", true) }
                    if (cont != null && cont.isEnabled && clickUp(cont)) clickedGoogle = true
                }
                consentTicks++
            } else if (click(r, PERM)) {
                acted = true
            } else if (email.isNotEmpty() && click(r, listOf(email))) {
                clickedGoogle = true; acted = true
            } else if (clickedGoogle && click(r, CONT)) {
                acted = true
            }
        }
        if (!acted && !clickedGoogle) {
            if (n == 1 && !tappedBox) { tapAt(boxX, boxY); tappedBox = true }
            else if (n >= 3 && (n - 3) % 8 == 0) tapAt(tapX, tapY)
        }
        h.postDelayed({ login(n + 1) }, 1500)
    }

    private fun click(root: AccessibilityNodeInfo, words: List<String>): Boolean {
        for (w in words) for (n in root.findAccessibilityNodeInfosByText(w)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }
}
